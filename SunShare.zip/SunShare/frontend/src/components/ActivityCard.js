import React from 'react';

export default function ActivityCard({ title, items }) {
  return (
    <div className="mt-4 p-4 border rounded shadow">
      <h2 className="font-semibold mb-2">{title}</h2>
      <ul className="list-disc list-inside">
        {items.map((i, idx) => <li key={idx}>{i}</li>)}
      </ul>
    </div>
  );
}
