import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function WeatherChart({ data }) {
  const labels = data.map(d => new Date(d.dt * 1000).toLocaleDateString());
  const temps = data.map(d => d.temp.day);
  return (
    <div className="mt-6">
      <h2 className="font-semibold mb-2">7-Day Temperature</h2>
      <Line
        data={{ labels, datasets: [{ label: '°C', data: temps }] }}
      />
    </div>
  );
}
